import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { EmployeeService } from '../services/employee';
import { Employee } from '../models/employee';

describe('EmployeeService', () => {
  let service: EmployeeService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [EmployeeService]
    });
    service = TestBed.inject(EmployeeService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => httpMock.verify());

  it('should fetch employees', () => {
    const dummy: Employee[] = [{ id:1, name:'A', address:'X', salary:1000 }];
    service.getEmployees().subscribe(res => {
      expect(res.length).toBe(1);
      expect(res).toEqual(dummy);
    });
    const req = httpMock.expectOne(service['apiUrl']);
    expect(req.request.method).toBe('GET');
    req.flush(dummy);
  });

  it('should add an employee', () => {
    const newEmp: Employee = { id:0, name:'N', address:'Y', salary:2000 };
    service.addEmployee(newEmp).subscribe(res => expect(res.name).toBe('N'));
    const req = httpMock.expectOne(service['apiUrl']);
    expect(req.request.method).toBe('POST');
    req.flush({ ...newEmp, id: 5 });
  });
});