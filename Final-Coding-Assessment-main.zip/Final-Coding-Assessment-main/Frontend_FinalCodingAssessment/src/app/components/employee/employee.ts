import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { EmployeeService } from '../../services/employee';
import { Employee } from '../../models/employee';

@Component({
  selector: 'app-employee',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
  <div class="container mt-4">
    <h2 class="text-center mb-4 text-primary">Employee Management</h2>

    <div class="card shadow p-4 mb-4">
      <h5 class="mb-3">{{ isEdit ? 'Edit Employee' : 'Add Employee' }}</h5>
      <form (ngSubmit)="isEdit ? updateEmployee() : addEmployee()">
        <div class="mb-3">
          <label class="form-label">Enter Name:</label>
          <input [(ngModel)]="employee.name" name="name" class="form-control" placeholder="Name" required />
        </div>
        <div class="mb-3">
          <label class="form-label">Enter Address:</label>
          <input [(ngModel)]="employee.address" name="address" class="form-control" placeholder="Address" required />
        </div>
        <div class="mb-3">
          <label class="form-label">Enter Salary:</label>
          <input type="number" [(ngModel)]="employee.salary" name="salary" class="form-control" placeholder="Salary" required />
        </div>
        <button class="btn btn-success me-2" type="submit">{{ isEdit ? 'Update' : 'Add' }}</button>
        <button *ngIf="isEdit" class="btn btn-secondary" type="button" (click)="cancelEdit()">Cancel</button>
      </form>
    </div>

    <div class="card shadow p-4">
      <h5 class="mb-3">Employees List</h5>
      <table class="table table-hover table-bordered align-middle">
        <thead class="table-dark">
          <tr>
            <th>No</th>
            <th>Name</th>
            <th>Address</th>
            <th>Salary</th>
            <th class="text-center">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let e of employees; let i = index">
            <td>{{ i + 1 }}</td>
            <td>{{ e.name }}</td>
            <td>{{ e.address }}</td>
            <td>{{ e.salary | currency:'USD' }}</td>
            <td class="text-center">
              <button class="btn btn-sm btn-warning me-2" (click)="editEmployee(e)">Edit</button>
              <button class="btn btn-sm btn-danger" (click)="deleteEmployee(e.id)">Delete</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
  `,
  styles: [`
    .container { max-width: 900px; }
    h2 { font-weight: 700; }
    .card { border-radius: 12px; }
    table th, table td { text-align: center; }
  `]
})
export class EmployeeComponent implements OnInit {
  employees: Employee[] = [];
  employee: Employee = { id: 0, name: '', address: '', salary: 0 };
  isEdit: boolean = false;

  constructor(private service: EmployeeService) {}

  ngOnInit() { this.load(); }

  load() {
    this.service.getEmployees().subscribe(res => this.employees = res);
  }

  addEmployee() {
    this.service.addEmployee(this.employee).subscribe(() => {
      this.resetForm();
      this.load();
    });
  }

  editEmployee(emp: Employee) {
    this.employee = { ...emp }; // copy values
    this.isEdit = true;
  }

  updateEmployee() {
    this.service.updateEmployee(this.employee).subscribe(() => {
      this.resetForm();
      this.load();
    });
  }

  deleteEmployee(id: number) {
    if (!confirm('Delete employee?')) return;
    this.service.deleteEmployee(id).subscribe(() => this.load());
  }

  cancelEdit() {
    this.resetForm();
  }

  private resetForm() {
    this.employee = { id: 0, name: '', address: '', salary: 0 };
    this.isEdit = false;
  }
}