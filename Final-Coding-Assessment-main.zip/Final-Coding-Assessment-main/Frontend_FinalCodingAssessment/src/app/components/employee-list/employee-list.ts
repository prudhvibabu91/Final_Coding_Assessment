import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { EmployeeService } from '../../services/employee';
import { Employee } from '../../models/employee';
@Component({
  selector: 'app-employee',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
  <div class="container mt-4">
    <h2 class="text-center mb-3">Employee Management</h2>

    <!-- Add Employee -->
    <div class="card p-3 mb-4">
      <h5>Add Employee</h5>
      <form (ngSubmit)="addEmployee()">
        <div class="mb-2">
          <label class="form-label">Enter Name:</label>
          <input [(ngModel)]="employee.name" name="name" class="form-control" placeholder="Name" required />
        </div>
        <div class="mb-2">
          <label class="form-label">Enter Address:</label>
          <input [(ngModel)]="employee.address" name="address" class="form-control" placeholder="Address" required />
        </div>
        <div class="mb-2">
          <label class="form-label">Enter Salary:</label>
          <input type="number" [(ngModel)]="employee.salary" name="salary" class="form-control" placeholder="Salary" required />
        </div>
        <button class="btn btn-primary" type="submit">Add</button>
      </form>
    </div>

    <!-- Employees Table -->
    <div class="card p-3">
      <h5>Employees</h5>
      <table class="table table-striped">
        <thead>
          <tr>
            <th>No.</th>
            <th>Id</th>
            <th>Name</th>
            <th>Address</th>
            <th>Salary</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let e of employees; let i = index">
            <td>{{ i + 1 }}</td>
            <td>{{ e.id }}</td>
            <td *ngIf="editId !== e.id">{{ e.name }}</td>
            <td *ngIf="editId === e.id">
              <input [(ngModel)]="editEmployee.name" class="form-control" />
            </td>
            <td *ngIf="editId !== e.id">{{ e.address }}</td>
            <td *ngIf="editId === e.id">
              <input [(ngModel)]="editEmployee.address" class="form-control" />
            </td>
            <td *ngIf="editId !== e.id">{{ e.salary | number:'1.0-2' }}</td>
            <td *ngIf="editId === e.id">
              <input type="number" [(ngModel)]="editEmployee.salary" class="form-control" />
            </td>
            <td>
              <button *ngIf="editId !== e.id" class="btn btn-sm btn-warning me-2" (click)="startEdit(e)">Edit</button>
              <button *ngIf="editId === e.id" class="btn btn-sm btn-success me-2" (click)="updateEmployee()">Save</button>
              <button *ngIf="editId === e.id" class="btn btn-sm btn-secondary me-2" (click)="cancelEdit()">Cancel</button>
              <button class="btn btn-sm btn-danger" (click)="deleteEmployee(e.id)">Delete</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
  `,
  styles: [`
    .container { max-width: 900px; }
    h2 { font-weight: 600; }
    .card { margin-bottom: 16px; }
    label { font-weight: 500; }
    input { min-width: 120px; }
  `]
})
export class EmployeeComponent implements OnInit {
  employees: Employee[] = [];
  employee: Employee = { id: 0, name: '', address: '', salary: 0 };

  editId: number | null = null;
  editEmployee: Employee = { id: 0, name: '', address: '', salary: 0 };

  constructor(private service: EmployeeService) {}

  ngOnInit() { this.load(); }

  load() {
    this.service.getEmployees().subscribe(res => this.employees = res);
  }

  addEmployee() {
    this.service.addEmployee(this.employee).subscribe(() => {
      this.employee = { id: 0, name: '', address: '', salary: 0 };
      this.load();
    });
  }

  deleteEmployee(id: number) {
    if (!confirm('Delete employee?')) return;
    this.service.deleteEmployee(id).subscribe(() => this.load());
  }

  startEdit(e: Employee) {
    this.editId = e.id;
    this.editEmployee = { ...e }; // copy current employee values
  }

  cancelEdit() {
    this.editId = null;
    this.editEmployee = { id: 0, name: '', address: '', salary: 0 };
  }

  updateEmployee() {
    this.service.updateEmployee(this.editEmployee).subscribe(() => {
      this.cancelEdit();
      this.load();
    });
  }
}