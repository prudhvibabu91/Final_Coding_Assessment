import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { EmployeeService } from '../../services/employee';
import { Employee } from '../../models/employee';


@Component({
  selector: 'app-employee-add',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container mt-3">
      <h2>Add Employee</h2>
      <form (ngSubmit)="addEmployee()">
        <div class="mb-3">
          <label class="form-label">Name</label>
          <input [(ngModel)]="employee.name" name="name" class="form-control" required />
        </div>
        <div class="mb-3">
          <label class="form-label">Address</label>
          <input [(ngModel)]="employee.address" name="address" class="form-control" required />
        </div>
        <div class="mb-3">
          <label class="form-label">Salary</label>
          <input type="number" [(ngModel)]="employee.salary" name="salary" class="form-control" required />
        </div>
        <button class="btn btn-primary" type="submit">Add Employee</button>
      </form>
    </div>
  `,
  styles: [`
    .container { max-width: 600px; }
    h2 { text-align: center; margin-bottom: 20px; }
  `]
})
export class EmployeeAddComponent {
  employee: Employee = { id: 0, name: '', address: '', salary: 0 };

  constructor(private empService: EmployeeService) {}

  addEmployee() {
    this.empService.addEmployee(this.employee).subscribe(() => {
      alert('Employee Added Successfully!');
      this.employee = { id: 0, name: '', address: '', salary: 0 };
    });
  }
}