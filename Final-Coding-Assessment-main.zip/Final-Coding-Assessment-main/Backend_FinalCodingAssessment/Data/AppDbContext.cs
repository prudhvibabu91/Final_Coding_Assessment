﻿using FinalAssessment_EmployeeAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace FinalAssessment_EmployeeAPI.Data
{

        public class AppDbContext : DbContext
        {
            public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

            public DbSet<Employee> Employees { get; set; }
        }
    }


