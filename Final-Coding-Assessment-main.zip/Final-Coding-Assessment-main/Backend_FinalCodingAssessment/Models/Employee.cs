﻿using System.ComponentModel.DataAnnotations.Schema;

namespace FinalAssessment_EmployeeAPI.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Address { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal Salary { get; set; }
    }
}
